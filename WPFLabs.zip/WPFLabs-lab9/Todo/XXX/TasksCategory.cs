﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Todo.XXX
{
    internal class TasksCategory
    {
        public string Title { get; set; }

        public SolidColorBrush TextColor { get; set; }
    }
}

